package com.IVA;

import java.util.Scanner;

public class IVA {
    public static void main(String[] args) {
        System.out.println("Hola te gustaria calcular el valor de un producto con el IVA agregado?");
        double iva = .19;

        Scanner scanner = new Scanner(System.in);
        System.out.println("Escribe el precio que te gustaria calcular");
        int numero = scanner.nextInt();

        double total = numero * iva;

        double total1 = total+numero;

            System.out.println("El valor de su precio final es: " + total);

            System.out.println ("El valor con IVA es: "+ total1);


    }
}
